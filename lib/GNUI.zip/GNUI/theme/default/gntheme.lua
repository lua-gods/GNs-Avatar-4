---@diagnostic disable: undefined-doc-name, undefined-field
--[[______   __
	/ ____/ | / / By: GNamimates | https://gnon.top | Discord: @gn8.
 / / __/  |/ / Theme File
/ /_/ / /|  / Contains how to theme specific classes
\____/_/ |_/ Source: link]]

--[[-< Layout >-─────
Theme
├Class
│ ├─DEFAULT
│ └─AnotherVariant
└─Class
  ├─DEFAULT
  ├─Variant
  └─MoreVariant
─────────────────────]]
---GNUI.Button        ->    Button
---GNUI.Button.Slider ->    Slider

local GNUI = require "../../main" ---@type GNUIAPI
local atlas = textures[(...):gsub("/",".") ..".gnuiTheme"]

---@type GNUI.Theme
local theme = {}

--[────────────────────────────────────────-< Box >-────────────────────────────────────────]--
theme.Box = {
	DEFAULT = {},
	Background = GNUI.newNineslice(atlas,23,8,27,12 ,2,2,2,2),
	Solid = GNUI.newNineslice(atlas,2,12,2,12)
}
--[────────────────────────────────────────-< Button >-────────────────────────────────────────]--
theme.Button = {
	DEFAULT = {
		NORMAL = GNUI.newNineslice(atlas,7,1,11,7 ,2,2,2,4, 2)
		:setTextColor(0,0,0)
		:setTextAlign(0.5,0.5)
		:setTextOffset(0,-1),
		PRESSED = GNUI.newNineslice(atlas,13,2,17,6 ,2,2,2,2)
		:setTextColor(0,0,0)
		:setTextAlign(0.5,0.5)
		:setTextOffset(0,-1)
		:setTextOffset(0,0),
	},
	SECONDARY = {
		NORMAL = GNUI.newNineslice(atlas,13,15,17,21 ,2,2,2,4, 2)
		:setTextAlign(0.5,0.5)
		:setTextOffset(0,-1)
		:setTextColor(1,1,1)
		:setTextEffect("SHADOW"),
		PRESSED = GNUI.newNineslice(atlas,19,17,23,21 ,2,2,2,2)
		:setTextAlign(0.5,0.5)
		:setTextOffset(0,1)
		:setTextColor(1,1,1)
		:setTextEffect("SHADOW"),
	},
	SECONDARY_FLAT = {
		NORMAL = GNUI.newNineslice(atlas,29,11,31,13 ,1,1,1,1)
		:setTextAlign(0.5,0.5),
		PRESSED = GNUI.newNineslice(atlas,29,15,31,17 ,1,1,1,1)
		:setTextAlign(0.5,0.5),
	},
	---@param box GNUI.Button
	FLAT = function (box)
		local spriteNormal = GNUI.newNineslice(atlas,9,13,11,15 ,1,1,1,1)
		local spritePressed = GNUI.newNineslice(atlas,5,13,7,15 ,1,1,1,1)
		
		box:setDefaultTextColor("black"):setTextAlign(0.5,0.5)
		local wasPressed = true
		local function update(pressed,hovering)
			if pressed ~= wasPressed then
				wasPressed = pressed
				if pressed then
					box:setSprite(spritePressed)
					GNUI.playSound("minecraft:ui.button.click",1) -- click
				else
					box:setSprite(spriteNormal)
				end
			end
		end
		box.BUTTON_CHANGED:register(update)
		update(false,false)
	end
}
-->========================================[ Slider ]=========================================<--
theme.Slider = {
	---@param box GNUI.Slider
	DEFAULT = function (box)
		local spriteButton = GNUI.newNineslice(atlas,7,1,11,7 ,2,2,2,4, 2)
		local spriteBG = GNUI.newNineslice(atlas,29,7,31,9, 1,1,1,1)
		
		box.sliderBox:setSprite(spriteButton)
		box.numberBox:setTextAlign(0.5,0.5)
		
	 
		local wasPressed = true
		local function update(pressed)
			
			if pressed ~= wasPressed then
				wasPressed = pressed
				if pressed then
					GNUI.playSound("minecraft:ui.button.click",1) -- click
				else
				end
			end
		end
		box.numberBox:setDefaultTextColor("white"):setTextEffect("OUTLINE")
		
		box:setSprite(spriteBG)
		box.BUTTON_CHANGED:register(update)
		update(false)
	end
}
-->========================================[ Text Field ]=========================================<--
theme.TextField = {
	DEFAULT = GNUI.newNineslice(atlas,13,9,17,13, 2,2,2,2),
}
-->========================================[ Separator ]=========================================<--
theme.Separator = {
	DEFAULT = GNUI.newNineslice(atlas,1,15,1,15)
}

return theme