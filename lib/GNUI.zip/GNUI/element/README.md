# Elements
> [!NOTE]
any of these elements can be deleted off of GNUI, as long as they are not used by other elements.

## dependency tree for elements

```
Box
├─Canvas
├─Button
│ ├─Slider
│ ├─TextField
│ └─GradientEdit
└─GridStacker

```